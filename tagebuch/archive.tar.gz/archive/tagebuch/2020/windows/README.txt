DSC02090:
chemitrode, oberflächlich, vermutlich etwas wie bio oder säure die irgendwie aktiviert wird

DSC02091:
über der linken lippenhälfte, chemitrode nach skizze (sorry "party" production) [1]
da muss erstens das gerinnungsmittel weg (Bzw. kann das auch z.B. sekundenleim sein, dann muss das biozeugs raus, das in der mitte sonst gibt das eine riesen schwellung, und die untere kapsel mit vermutlich auch sekundenleim muss auch raus

da wäre die frage, bzw man müsste mal berechnen ob man das zB. mit einem blasrohr als multi chemitroden projektil applizieren kann, gewicht <-> impuls <= distanz?

BioWaffeWerHatDieseAngebrachtDientAlsUnterstuetzungUmSuizidZuInduzierenMitigationGegenSuizidR905bzwActiveDenialSystemeUndCommChannelsDeaktivieren.pdf



ich bestell mal diese dinger (saugZeugs.png) das ist zwar eigentlich sex spielzeug, aber vermtulcih wäre das für diesen use-case auch nützlich...


falls es wirklich projektile sind, müsste es abschuss vorrichtungen geben, siehe video myth busters mit cpu vs gpu 

diese gäbe es zu finden, sichern, spuren sichern und davon ausgehen dass die täterschaft da dna spuren von sündenböcken dran gemacht hat, bzw. a14, wie die mitpatientin in der psychiatrie königsfeldne gedacht hat, sie könne jetzt meine unterwäsche mitnhemnen als sie gemeint hat ich schlafe, das hat mich dann so angeekelt, dass ich das in der psychiatrie fortgeschmissen habe, ich hätte die gescheiter verbrannt


04:17 14.12.2020


dann scheint jetzt magersucht malware aktiviert worden zu sein, bzw. die Koch malware, sexuelle bedrängung beim kochen und malware upgedatet worden zu sein um dann wieder mal "legitim" einen StGB 59 auszusprechen wegen magersucht

=> select * from magersucht FFE/FU @psychiatrieKönigsfelden, allenfalls kronzeugen, vergewaltigungsopfer, whitehats oder whistelbower

ich hab jetzt mal ganz viele kartoffeln in die pfanne gehauen und ganz viel öl was man wenn man fett ist nicht tun sollte....

apropos "everythingIsFine.png" da versiffe ich immer die Schere etc. zum pfläschterli schneiden zu versorgen etc. dann müssten die nur 1 sek auf mein medulla spinalis zugriff haben und könnten mich "selber" abstechen...

apropos ebd vor ca 24h mit der Kiste mit dem sprit und messer drin...

dann bin ich zu wenig gut in chemie, aber mit genügend energie auf der richtigen frequenz, könnte man z.B. auch sprit, desinfektionsmitte, bodylotion in verschiedene molekül aufteilen aus dem eigentlich guten molekül, wie in Bi-Won von Limp Ninja dargestellt?




05:07 14.12.2020
dann nochmals einen nützlcihen datenpunkt / leak

wenn man alle meine muskeln zu einer achse definiert, könnte man mit matrizen berechnungen lineare bewegungen machen, z.B. volle tasse irgendwo hin stellen. (siehe forward/reverse kinematik karte)
allenfalls gäbe es eine malware auf der untersten ebene, mit der man dann die achsen doppelt so schnell laufen lassen könnte, wo die überen API's nichts davon mitbekommen würden um z.B. den kaffee in der tasse auszuschütten und dann wieder blah verwahrlosungsartikel machen könnte <- LAWFARE, verwarlosungsartikel lenkt von malware ab

die bewegung würde wegen behavioral prediction nach behavioral recognition einigermassen bekannt sein

wichtig, achs-servo steuerung (muskeln) allenfallsd auch hacked....





